import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


/**
 *
 * @author aksata
 */
public class Koneksi {
   Connection konek = null;
   
   public static Connection KoneksiDB(){
       try{
          String url = "jdbc:mysql://localhost/ukk_dewiaisyah";
          String user= "root";
          String pass ="";
          Class.forName("com.mysql.jdbc.Driver");
          Connection Koneksi = DriverManager.getConnection(url, user, pass);
          return Koneksi;
           
   }
       catch (Exception e) {
          JOptionPane.showMessageDialog(null, e);
          return null;
       } 
      
   }
           
   
}