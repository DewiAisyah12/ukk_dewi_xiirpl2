-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Feb 2024 pada 08.11
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ukk_dewiaisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bukudewi`
--

CREATE TABLE `bukudewi` (
  `BukuID` int(5) NOT NULL,
  `Judul` varchar(20) NOT NULL,
  `Penulis` varchar(25) NOT NULL,
  `Penerbit` varchar(25) NOT NULL,
  `Tahun Terbit` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `logindewi`
--

CREATE TABLE `logindewi` (
  `Username` varchar(10) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `logindewi`
--

INSERT INTO `logindewi` (`Username`, `Password`) VALUES
('dewi', 'dewi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjamandewi`
--

CREATE TABLE `peminjamandewi` (
  `PeminjamanID` int(5) NOT NULL,
  `UserID` int(5) NOT NULL,
  `BukuID` int(5) NOT NULL,
  `TanggalPeminjaman` date NOT NULL,
  `TanggalPengembalian` date NOT NULL,
  `StatusPeminjaman` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `userdewi`
--

CREATE TABLE `userdewi` (
  `UserID` int(5) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `NamaLengkap` varchar(25) NOT NULL,
  `Alamat` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bukudewi`
--
ALTER TABLE `bukudewi`
  ADD PRIMARY KEY (`BukuID`);

--
-- Indeks untuk tabel `logindewi`
--
ALTER TABLE `logindewi`
  ADD PRIMARY KEY (`Username`);

--
-- Indeks untuk tabel `peminjamandewi`
--
ALTER TABLE `peminjamandewi`
  ADD PRIMARY KEY (`PeminjamanID`);

--
-- Indeks untuk tabel `userdewi`
--
ALTER TABLE `userdewi`
  ADD PRIMARY KEY (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
